// Nikhil Kowdle
// CS1400
// Assignment 1
// 7 February 2021

public class HelloWorld
{
    public static void main(String[]args) {
        System.out.println("Hello World, my name is Nikhil, and I like reading.");
        System.out.println("I have been programming for 6 years.");
    }
}